/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.stanford.folding.msmexplorer;

/**
 *
 * @author gestalt
 */
public interface MSMConstants {

	public static final String LABEL = "label";
	public static final String EQPROB = "eqProb";
	public static final String TPROB = "probability";
	
}
