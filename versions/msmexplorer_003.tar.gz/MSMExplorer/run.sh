#!/bin/sh

java -jar ./MSMExplorer.jar
